from typing import Dict

status: Dict[str, dict] = {}
