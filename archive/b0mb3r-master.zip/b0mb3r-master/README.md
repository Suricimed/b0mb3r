<h1 align="center">Добро пожаловать в b0mb3r 👋</h1>
<p align="center">
    Открытый и бесплатный СМС бомбер
    <br /><br />
    <img alt="Made with Python" src="https://img.shields.io/badge/Made%20with-Python-%23FFD242?logo=python&logoColor=white">
    <img alt="Downloads" src="https://pepy.tech/badge/b0mb3r">
    <img alt="Repo size" src="https://img.shields.io/github/repo-size/crinny/b0mb3r">
    <img alt="Code style: black" src="https://img.shields.io/badge/code%20style-black-000000.svg">
</p>

## 🚀 Установка

1. Установите Python версии не ниже 3.7. Сделать это можно так:

    <h3>Для Windows</h3>

    Скачайте установщик с [официального сайта](https://www.python.org/downloads/) и запустите его. Убедитесь, что при установке отметили галочку ![Add Python to PATH](https://user-images.githubusercontent.com/42045258/69171091-557d2780-0b0c-11ea-8adf-7f819357f041.png)

    <h3>Для Android</h3>

    Установите приложение [Termux](https://play.google.com/store/apps/details?id=com.termux), запустите его и введите следующую команду:
     ```sh
     pkg install python clang make -y
     ```
     <h3>Для Linux</h3>

     Скорее всего, у вас уже установлен Python 3. Если это не так, следуйте [инструкции](https://realpython.com/installing-python/#linux)
     

2. Введите следующую команду в [командную строку](http://comp-profi.com/kak-vyzvat-komandnuyu-stroku-ili-konsol-windows/) (Windows), терминал (Linux) или Termux (Android):

```sh
pip3 install b0mb3r -U
```

## 🚩 Запуск

Всё просто! Введите команду `b0mb3r` или `bomber` и интерфейс бомбера будет запущен. Команда доступна из любой директории.

## 💻 Расширенное использование

Смотреть [Wiki](https://github.com/crinny/b0mb3r/wiki).

## 📝 Лицензия
<!--- Не надо это удалять, пожалуйста 😐  -->
Проект распространяется под лицензией [Mozilla Public License 2.0](https://github.com/crinny/b0mb3r/blob/master/LICENSE). Скачивая программное обеспечение из [этого](https://github.com/crinny/b0mb3r) репозитория, вы соглашаетесь с ней. По условиям лицензии вы обязаны выкладывать исходный код ваших модификаций под той же лицензией.


## Остались вопросы?
1. Убедитесь, что прочли этот документ полностью
2. Прочтите [это](http://neprivet.ru/)
3. Напишите мне в [Telegram](https://t.me/crinny) или в чат: [@b0mb3r4at](https://t.me/b0mb3r4at)

Канал с новостями о разработке в Telegram: [@b0mb3rch](https://t.me/b0mb3rch).


## Stargazers over time

[![Stargazers over time](https://starchart.cc/crinny/b0mb3r.svg)](https://starchart.cc/crinny/b0mb3r)
